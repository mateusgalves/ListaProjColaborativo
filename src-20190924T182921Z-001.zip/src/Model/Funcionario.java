/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author aluno
 */
public class Funcionario extends Pessoa {
    private double salario;
    private String cargo;

    
     public Funcionario(){
         
     }
    public Funcionario(double salario, String cargo) {
        this.salario = salario;
        this.cargo = cargo;
    }

    
    
    
    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    
    
}
